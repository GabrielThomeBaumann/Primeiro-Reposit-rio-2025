let scoreA = 0;
let scoreB = 0;
let setsA = 0;
let setsB = 0;

function updateScore() {
    document.getElementById("scoreA").innerText = scoreA;
    document.getElementById("scoreB").innerText = scoreB;
    document.getElementById("setsA").innerText = setsA;
    document.getElementById("setsB").innerText = setsB;
}

function addPoint(team) {
    if (team === 'A') {
        scoreA++;
        addToHistory("Time A marcou um ponto.");
    } else {
        scoreB++;
        addToHistory("Time B marcou um ponto.");
    }
    updateScore();
}

function addSet(team) {
    if (team === 'A') {
        setsA++;
        addToHistory("Time A ganhou um set.");
    } else {
        setsB++;
        addToHistory("Time B ganhou um set.");
    }
    updateScore();
}

function addToHistory(text) {
    const historyList = document.getElementById("historyList");
    const newItem = document.createElement("li");
    newItem.textContent = text;
    historyList.prepend(newItem);
}
